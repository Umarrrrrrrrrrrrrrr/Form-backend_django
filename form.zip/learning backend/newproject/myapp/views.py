from django.shortcuts import redirect, render, HttpResponse
from .models import UserData

# Create your views here.
def index(request):
    return render(request, 'index.html')

def about(request):
    return render(request, 'about.html')

def service(request):
    return render(request, 'service.html')

def contact(request):
    return render(request, 'contact.html')

def saveData(request):
    if request.method == "POST":
        username = request.POST.get("username")
        password = request.POST.get("password")
        if username and password:
            UserData.objects.create(username = username, password = password)
            return redirect('success')
    return render(request, 'index.html')

def success(request):
    return render(request, 'success.html')